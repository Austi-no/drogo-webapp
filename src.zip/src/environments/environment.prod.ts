export const environment = {
  production: true,
  backend: {
    baseURL: 'http://199.192.17.111:3080/api/v1/endpoint/closure/webApp'

  }
};
